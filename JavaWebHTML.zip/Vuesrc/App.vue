<template>
  <div>
    <!--  引入的组件和***View.vu
          <emp-view></emp-view> 
          <element-view></element-view>    -->
    <!-- 这里通过router-view动态展示标签 -->
    <router-view></router-view>
  </div>
</template>
<style></style>
<script>
/* import elementView from './views/element/elementView.vue'
  import EmpView from './views/element/empView.vue'*/
export default {
  components: {
    /* empView 
    elementView */
  },
  data() {
    return {
      message: "Hello Vue"
    }
  },
  methods: {}
} 
</script>
