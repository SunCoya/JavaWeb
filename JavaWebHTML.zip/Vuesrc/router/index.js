import Vue from 'vue'
import VueRouter from 'vue-router'
/*  
实现页面切换功能 
    前端路由：URL中的hash与组件之间的对应关系
    VueRouter：Vue的官方路由，路由器类，包含了路由表，根据路由请求（URL）在路由视图中动态渲染的组件（显示）
    router-link：请求链接组件，浏览器会请求为<a>
    router-view：动态视图组件，可以在任何区域展示与这个url对应的组件 
*/

Vue.use(VueRouter)
const routes = [
  //在这里配置路由信息
  {
    path: '/emp',
    name: 'emp',
    component: () => import('../views/element/empView.vue')
  },
  {
    path: '/dept',
    name: 'dept',
    component: () => import('../views/element/homework.vue')
  },
  {
    path: '/element',
    name: 'element',
    component: () => import('../views/element/elementView.vue')
  },
  //配置根路径：防止找不到首页
  {
    path: '/',
    redirect: '/dept'
  }
]
const router = new VueRouter({
  routes
})
export default router